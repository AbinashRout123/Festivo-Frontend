import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

  constructor(public service: ProductService) { }

  categories: any;

  ngOnInit() {
    this.service.GetCategory().subscribe(
      (res: any) => {
        this.categories = res;
        console.log(res);
      }
    );
  }

  onSubmit() {
    return this.service.LoadProducts().subscribe();
  }
}
