import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService } from './category.service';


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(public router: Router, public route: ActivatedRoute, public cat: CategoryService) { }
  id;
  category: any;

  ngOnInit() {
    this.cat.GetCategory()
      .subscribe(
        result => {
          console.log(result),
            this.category = result;
        },
        error => {
          console.log(error);
        }
      );
  }

  onSubmit() {
    return this.cat.LoadCategory().subscribe();
  }

  deleteCategory(categoryId) {
    const ans = confirm('Are you sure you want to delete ?');
    if (ans) {
      this.id = this.category.categoryId;
      this.cat.DeleteCategory(categoryId).subscribe(() => {
        this.ngOnInit();
      });
    }
  }



}
