export class EditModel {

  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  contact: string;
  password: string;
}
