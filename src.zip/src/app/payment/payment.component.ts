import { Component, OnInit } from '@angular/core';
import { PaymentService } from './payment.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(public service: PaymentService, public toaster: ToastrService) { }

  ngOnInit() {
  }

  onSubmit() {
    this.service.AddPayment().subscribe(
      (response: any) => {
        console.log(response.saved);
      }
    );
  }

  orderPlaced() {
    this.toaster.success('Your order has been placed successfully');
  }
}
