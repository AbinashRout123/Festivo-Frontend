export class Payment {
  public nameOnCard: string;
  public cardNumber: string;
  public monthOfExpiry: string;
  public yearOfExpiry: string;
  public cvv: string;
}
