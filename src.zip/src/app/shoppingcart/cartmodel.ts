export class Cart {
  public UserId: number;
  public ProductId: number;
  public Quantity: number;
  public Price: number;
  public Total: number;
}

