export class Checkout {

  public userId: number;
  public firstName: string;
  public lastName: string;
  public email: string;
  public address: string;
  public state: string;
  public city: string;
  public pinCode: string;
  public phoneNumber: string;
}
